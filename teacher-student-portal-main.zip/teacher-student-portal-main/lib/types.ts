export type UserRole = "teacher" | "student"

export interface User {
  id: string
  email: string
  full_name: string
  role: UserRole
  created_at: string
  updated_at: string
}

export type QuestionType = "multiple_choice" | "short_answer" | "essay"

export interface Question {
  id: string
  teacher_id: string
  title: string
  description: string | null
  question_text: string
  question_type: QuestionType
  options: string[] | null
  correct_answer: string | null
  created_at: string
  updated_at: string
}

export interface StudentResponse {
  id: string
  question_id: string
  student_id: string
  answer: string
  is_correct: boolean | null
  submitted_at: string
}
