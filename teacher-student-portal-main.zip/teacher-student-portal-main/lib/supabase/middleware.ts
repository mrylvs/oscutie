import { NextResponse, type NextRequest } from "next/server"

export async function updateSession(request: NextRequest) {
  // For Next.js runtime, we don't need complex middleware
  // Just pass through the request
  return NextResponse.next({
    request,
  })
}
