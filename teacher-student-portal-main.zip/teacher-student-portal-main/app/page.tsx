import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowRight, BookOpen, BarChart3, Users } from "lucide-react"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 py-4 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <BookOpen className="w-8 h-8 text-blue-600" />
          <span className="text-2xl font-bold text-gray-900">EduPortal</span>
        </div>
        <div className="flex gap-4">
          <Link href="/auth/signin">
            <Button variant="outline">Sign In</Button>
          </Link>
          <Link href="/auth/signup">
            <Button>Get Started</Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-20 text-center">
        <h1 className="text-5xl font-bold text-gray-900 mb-6 text-balance">
          Modern Learning Platform for Teachers and Students
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto text-balance">
          Create, share, and track educational content with an intuitive platform designed for modern classrooms.
        </p>
        <div className="flex gap-4 justify-center">
          <Link href="/auth/signup">
            <Button size="lg" className="gap-2">
              Start Teaching <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
          <Link href="/auth/signup">
            <Button size="lg" variant="outline">
              Start Learning
            </Button>
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Why Choose EduPortal?</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="p-8 border-0 shadow-lg hover:shadow-xl transition-shadow">
            <BookOpen className="w-12 h-12 text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Easy Question Management</h3>
            <p className="text-gray-600">
              Teachers can easily create and manage multiple types of questions with instant feedback.
            </p>
          </Card>

          <Card className="p-8 border-0 shadow-lg hover:shadow-xl transition-shadow">
            <Users className="w-12 h-12 text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Student Engagement</h3>
            <p className="text-gray-600">
              Students can answer questions, track their progress, and get instant feedback on their work.
            </p>
          </Card>

          <Card className="p-8 border-0 shadow-lg hover:shadow-xl transition-shadow">
            <BarChart3 className="w-12 h-12 text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Progress Analytics</h3>
            <p className="text-gray-600">
              Track student performance with detailed analytics and insights to improve teaching effectiveness.
            </p>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-6 py-20 text-center">
        <Card className="p-12 border-0 bg-blue-600 text-white shadow-lg">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Classroom?</h2>
          <p className="text-lg mb-8 text-blue-100">Join thousands of educators using EduPortal today.</p>
          <Link href="/auth/signup">
            <Button size="lg" variant="secondary">
              Create Your Account Now
            </Button>
          </Link>
        </Card>
      </section>
    </div>
  )
}
