"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { BookOpen, AlertCircle } from "lucide-react"
import { signUpUser } from "@/app/actions/auth"

type UserRole = "teacher" | "student"

export default function SignUpPage() {
  const router = useRouter()
  const [role, setRole] = useState<UserRole | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    fullName: "",
    schoolName: "",
    subject: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    try {
      if (!role) {
        setError("Please select a role")
        setLoading(false)
        return
      }

      if (formData.password !== formData.confirmPassword) {
        setError("Passwords do not match")
        setLoading(false)
        return
      }

      if (formData.password.length < 6) {
        setError("Password must be at least 6 characters")
        setLoading(false)
        return
      }

      const result = await signUpUser(
        formData.email,
        formData.password,
        formData.fullName,
        role,
        role === "teacher" ? formData.schoolName : undefined,
        role === "teacher" ? formData.subject : undefined,
      )

      if (result.error) {
        setError(result.error)
        setLoading(false)
        return
      }

      // Redirect to appropriate dashboard
      router.push(role === "teacher" ? "/teacher/dashboard" : "/student/dashboard")
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  if (!role) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 border-0 shadow-lg">
          <div className="flex items-center justify-center gap-2 mb-8">
            <BookOpen className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">EduPortal</h1>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-2 text-center">Choose Your Role</h2>
          <p className="text-gray-600 text-center mb-8">Select whether you are a teacher or student</p>

          <div className="space-y-4">
            <button
              onClick={() => setRole("teacher")}
              className="w-full p-6 border-2 border-gray-200 rounded-lg hover:border-blue-600 hover:bg-blue-50 transition-all text-left"
            >
              <h3 className="font-semibold text-gray-900 mb-2">I'm a Teacher</h3>
              <p className="text-sm text-gray-600">Create and manage questions for your students</p>
            </button>

            <button
              onClick={() => setRole("student")}
              className="w-full p-6 border-2 border-gray-200 rounded-lg hover:border-blue-600 hover:bg-blue-50 transition-all text-left"
            >
              <h3 className="font-semibold text-gray-900 mb-2">I'm a Student</h3>
              <p className="text-sm text-gray-600">Answer questions and track your progress</p>
            </button>
          </div>

          <p className="text-center text-gray-600 mt-8">
            Already have an account?{" "}
            <Link href="/auth/signin" className="text-blue-600 font-semibold hover:underline">
              Sign In
            </Link>
          </p>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 border-0 shadow-lg">
        <div className="flex items-center justify-center gap-2 mb-8">
          <BookOpen className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">EduPortal</h1>
        </div>

        <h2 className="text-2xl font-bold text-gray-900 mb-2 text-center">
          {role === "teacher" ? "Teacher Sign Up" : "Student Sign Up"}
        </h2>
        <p className="text-gray-600 text-center mb-8">Create your account to get started</p>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        <form onSubmit={handleSignUp} className="space-y-4">
          <div>
            <Label htmlFor="fullName">Full Name</Label>
            <Input
              id="fullName"
              name="fullName"
              type="text"
              placeholder="John Doe"
              value={formData.fullName}
              onChange={handleInputChange}
              required
            />
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              name="email"
              type="email"
              placeholder="you@example.com"
              value={formData.email}
              onChange={handleInputChange}
              required
            />
          </div>

          <div>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              name="password"
              type="password"
              placeholder="••••••••"
              value={formData.password}
              onChange={handleInputChange}
              required
            />
          </div>

          <div>
            <Label htmlFor="confirmPassword">Confirm Password</Label>
            <Input
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              placeholder="••••••••"
              value={formData.confirmPassword}
              onChange={handleInputChange}
              required
            />
          </div>

          {role === "teacher" && (
            <div>
              <Label htmlFor="schoolName">School/Institution Name</Label>
              <Input
                id="schoolName"
                name="schoolName"
                type="text"
                placeholder="Your School"
                value={formData.schoolName}
                onChange={handleInputChange}
              />
            </div>
          )}

          {role === "teacher" && (
            <div>
              <Label htmlFor="subject">Subject/Grade</Label>
              <Input
                id="subject"
                name="subject"
                type="text"
                placeholder="e.g., Mathematics Grade 10"
                value={formData.subject}
                onChange={handleInputChange}
              />
            </div>
          )}

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Creating Account..." : "Sign Up"}
          </Button>
        </form>

        <div className="mt-6 flex gap-2">
          <button
            onClick={() => setRole(null)}
            className="flex-1 py-2 px-4 text-sm text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            Back
          </button>
          <p className="flex-1 text-center text-gray-600 text-sm">
            Already have an account?{" "}
            <Link href="/auth/signin" className="text-blue-600 font-semibold hover:underline">
              Sign In
            </Link>
          </p>
        </div>
      </Card>
    </div>
  )
}
