"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, Users, FileText, TrendingUp } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"

interface DashboardStats {
  totalQuestions: number
  totalStudents: number
  totalResponses: number
  averageScore: number
}

export default function TeacherDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalQuestions: 0,
    totalStudents: 0,
    totalResponses: 0,
    averageScore: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      const supabase = getSupabaseClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) return

      // Get teacher's questions
      const { data: questions } = await supabase.from("questions").select("id").eq("teacher_id", user.id)

      const questionIds = questions?.map((q) => q.id) || []

      // Get all responses to teacher's questions
      const { data: responses } = await supabase
        .from("student_responses")
        .select("*")
        .in("question_id", questionIds.length > 0 ? questionIds : [""])

      // Get unique students who answered
      const uniqueStudents = new Set(responses?.map((r) => r.student_id) || [])

      // Calculate average score
      const correctResponses = responses?.filter((r) => r.is_correct).length || 0
      const averageScore = responses && responses.length > 0 ? (correctResponses / responses.length) * 100 : 0

      setStats({
        totalQuestions: questions?.length || 0,
        totalStudents: uniqueStudents.size,
        totalResponses: responses?.length || 0,
        averageScore: Math.round(averageScore),
      })
      setLoading(false)
    }

    fetchStats()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Teacher Dashboard</h1>
        <Link href="/teacher/questions/new">
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            Create Question
          </Button>
        </Link>
      </div>

      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <Card className="p-6 border-0 shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Total Questions</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalQuestions}</p>
            </div>
            <FileText className="w-12 h-12 text-blue-100" />
          </div>
        </Card>

        <Card className="p-6 border-0 shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Students Engaged</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalStudents}</p>
            </div>
            <Users className="w-12 h-12 text-green-100" />
          </div>
        </Card>

        <Card className="p-6 border-0 shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Total Responses</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalResponses}</p>
            </div>
            <FileText className="w-12 h-12 text-amber-100" />
          </div>
        </Card>

        <Card className="p-6 border-0 shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Average Score</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.averageScore}%</p>
            </div>
            <TrendingUp className="w-12 h-12 text-emerald-100" />
          </div>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-8 border-0 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Quick Actions</h2>
          <div className="space-y-3">
            <Link href="/teacher/questions/new" className="block">
              <Button variant="outline" className="w-full justify-start bg-transparent">
                <Plus className="w-4 h-4 mr-2" />
                Create New Question
              </Button>
            </Link>
            <Link href="/teacher/questions" className="block">
              <Button variant="outline" className="w-full justify-start bg-transparent">
                <FileText className="w-4 h-4 mr-2" />
                View All Questions
              </Button>
            </Link>
            <Link href="/teacher/analytics" className="block">
              <Button variant="outline" className="w-full justify-start bg-transparent">
                <TrendingUp className="w-4 h-4 mr-2" />
                View Analytics
              </Button>
            </Link>
          </div>
        </Card>

        <Card className="p-8 border-0 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Class Overview</h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Student Engagement</span>
                <span className="text-sm font-bold text-gray-900">
                  {stats.totalQuestions > 0
                    ? Math.round(
                        (stats.totalResponses / (stats.totalQuestions * Math.max(stats.totalStudents, 1))) * 100,
                      )
                    : 0}
                  %
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all"
                  style={{
                    width: `${
                      stats.totalQuestions > 0
                        ? Math.round(
                            (stats.totalResponses / (stats.totalQuestions * Math.max(stats.totalStudents, 1))) * 100,
                          )
                        : 0
                    }%`,
                  }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Class Performance</span>
                <span className="text-sm font-bold text-gray-900">{stats.averageScore}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-600 h-2 rounded-full transition-all"
                  style={{ width: `${stats.averageScore}%` }}
                ></div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
