"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { getSupabaseClient } from "@/lib/supabase/client"

interface StudentPerformance {
  student_id: string
  student_name: string
  total_answered: number
  correct_answers: number
  accuracy: number
}

interface QuestionPerformance {
  question_id: string
  question_title: string
  total_responses: number
  correct_responses: number
  accuracy: number
}

interface AnalyticsData {
  studentPerformance: StudentPerformance[]
  questionPerformance: QuestionPerformance[]
  overallStats: {
    totalStudents: number
    totalQuestions: number
    totalResponses: number
    averageAccuracy: number
  }
}

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchAnalytics = async () => {
      const supabase = getSupabaseClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) return

      // Get teacher's questions
      const { data: questions } = await supabase.from("questions").select("id, title").eq("teacher_id", user.id)

      const questionIds = questions?.map((q) => q.id) || []

      if (questionIds.length === 0) {
        setData({
          studentPerformance: [],
          questionPerformance: [],
          overallStats: {
            totalStudents: 0,
            totalQuestions: 0,
            totalResponses: 0,
            averageAccuracy: 0,
          },
        })
        setLoading(false)
        return
      }

      // Get all responses to teacher's questions
      const { data: responses } = await supabase.from("student_responses").select("*").in("question_id", questionIds)

      // Get student information - ensure we're fetching all students with responses
      const studentIds = [...new Set(responses?.map((r) => r.student_id) || [])]

      if (studentIds.length === 0) {
        setData({
          studentPerformance: [],
          questionPerformance: [],
          overallStats: {
            totalStudents: 0,
            totalQuestions: questionIds.length,
            totalResponses: 0,
            averageAccuracy: 0,
          },
        })
        setLoading(false)
        return
      }

      const { data: students, error: studentsError } = await supabase
        .from("users")
        .select("id, full_name")
        .in("id", studentIds)

      console.log("Students fetched:", students, "Error:", studentsError)

      const studentsMap = new Map(students?.map((s) => [s.id, s.full_name]) || [])

      // Calculate student performance
      const studentPerformanceMap = new Map<string, StudentPerformance>()

      responses?.forEach((response) => {
        const existing = studentPerformanceMap.get(response.student_id) || {
          student_id: response.student_id,
          student_name: studentsMap.get(response.student_id) || "Unknown",
          total_answered: 0,
          correct_answers: 0,
          accuracy: 0,
        }

        existing.total_answered += 1
        if (response.is_correct) {
          existing.correct_answers += 1
        }
        existing.accuracy = Math.round((existing.correct_answers / existing.total_answered) * 100)

        studentPerformanceMap.set(response.student_id, existing)
      })

      // Calculate question performance
      const questionPerformanceMap = new Map<string, QuestionPerformance>()

      const questionsMap = new Map(questions?.map((q) => [q.id, q.title]) || [])

      responses?.forEach((response) => {
        const existing = questionPerformanceMap.get(response.question_id) || {
          question_id: response.question_id,
          question_title: questionsMap.get(response.question_id) || "Unknown",
          total_responses: 0,
          correct_responses: 0,
          accuracy: 0,
        }

        existing.total_responses += 1
        if (response.is_correct) {
          existing.correct_responses += 1
        }
        existing.accuracy = Math.round((existing.correct_responses / existing.total_responses) * 100)

        questionPerformanceMap.set(response.question_id, existing)
      })

      // Calculate overall stats
      const totalCorrect = responses?.filter((r) => r.is_correct).length || 0
      const averageAccuracy =
        responses && responses.length > 0 ? Math.round((totalCorrect / responses.length) * 100) : 0

      const studentPerfArray = Array.from(studentPerformanceMap.values())
      const questionPerfArray = Array.from(questionPerformanceMap.values())

      console.log("Student Performance Data:", studentPerfArray)
      console.log("Question Performance Data:", questionPerfArray)

      setData({
        studentPerformance: studentPerfArray,
        questionPerformance: questionPerfArray,
        overallStats: {
          totalStudents: studentIds.length,
          totalQuestions: questionIds.length,
          totalResponses: responses?.length || 0,
          averageAccuracy,
        },
      })
      setLoading(false)
    }

    fetchAnalytics()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading analytics...</p>
        </div>
      </div>
    )
  }

  if (!data || data.overallStats.totalQuestions === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600 text-lg">
          No data available yet. Create questions and have students answer them to see analytics.
        </p>
      </div>
    )
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Analytics Dashboard</h1>

      {/* Overall Stats */}
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <Card className="p-6 border-0 shadow-md">
          <p className="text-gray-600 text-sm font-medium">Total Students</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{data.overallStats.totalStudents}</p>
        </Card>

        <Card className="p-6 border-0 shadow-md">
          <p className="text-gray-600 text-sm font-medium">Total Questions</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{data.overallStats.totalQuestions}</p>
        </Card>

        <Card className="p-6 border-0 shadow-md">
          <p className="text-gray-600 text-sm font-medium">Total Responses</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{data.overallStats.totalResponses}</p>
        </Card>

        <Card className="p-6 border-0 shadow-md">
          <p className="text-gray-600 text-sm font-medium">Average Accuracy</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{data.overallStats.averageAccuracy}%</p>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* Student Performance Chart */}
        <Card className="p-6 border-0 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Student Performance</h2>
          {data.studentPerformance.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={data.studentPerformance}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="student_name" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="accuracy" fill="#3b82f6" name="Accuracy %" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-gray-600 text-center py-8">No student data available</p>
          )}
        </Card>

        {/* Question Performance Chart */}
        <Card className="p-6 border-0 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Question Performance</h2>
          {data.questionPerformance.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={data.questionPerformance}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="question_title" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="accuracy" fill="#10b981" name="Accuracy %" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-gray-600 text-center py-8">No question data available</p>
          )}
        </Card>
      </div>

      {/* Detailed Tables */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Student Performance Table */}
        <Card className="p-6 border-0 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Student Details</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Student</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-900">Answered</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-900">Correct</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-900">Accuracy</th>
                </tr>
              </thead>
              <tbody>
                {data.studentPerformance.map((student) => (
                  <tr key={student.student_id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4 text-gray-900">{student.student_name}</td>
                    <td className="py-3 px-4 text-center text-gray-600">{student.total_answered}</td>
                    <td className="py-3 px-4 text-center text-gray-600">{student.correct_answers}</td>
                    <td className="py-3 px-4 text-center">
                      <Badge variant={student.accuracy >= 70 ? "default" : "secondary"}>{student.accuracy}%</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Question Performance Table */}
        <Card className="p-6 border-0 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Question Details</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Question</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-900">Responses</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-900">Correct</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-900">Accuracy</th>
                </tr>
              </thead>
              <tbody>
                {data.questionPerformance.map((question) => (
                  <tr key={question.question_id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4 text-gray-900 truncate">{question.question_title}</td>
                    <td className="py-3 px-4 text-center text-gray-600">{question.total_responses}</td>
                    <td className="py-3 px-4 text-center text-gray-600">{question.correct_responses}</td>
                    <td className="py-3 px-4 text-center">
                      <Badge variant={question.accuracy >= 70 ? "default" : "secondary"}>{question.accuracy}%</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  )
}
