"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, Edit, Trash2, Eye } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Question } from "@/lib/types"

export default function TeacherQuestionsPage() {
  const [questions, setQuestions] = useState<Question[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchQuestions()
  }, [])

  const fetchQuestions = async () => {
    const supabase = getSupabaseClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) return

    const { data } = await supabase.from("questions").select("*").eq("teacher_id", user.id).order("created_at", {
      ascending: false,
    })

    setQuestions(data || [])
    setLoading(false)
  }

  const handleDelete = async (questionId: string) => {
    if (!confirm("Are you sure you want to delete this question?")) return

    const supabase = getSupabaseClient()
    const { error } = await supabase.from("questions").delete().eq("id", questionId)

    if (!error) {
      setQuestions(questions.filter((q) => q.id !== questionId))
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading questions...</p>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900">My Questions</h1>
        <Link href="/teacher/questions/new">
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            Create Question
          </Button>
        </Link>
      </div>

      {questions.length === 0 ? (
        <Card className="p-12 text-center border-0 shadow-md">
          <p className="text-gray-600 text-lg mb-4">No questions created yet</p>
          <Link href="/teacher/questions/new">
            <Button>Create Your First Question</Button>
          </Link>
        </Card>
      ) : (
        <div className="space-y-4">
          {questions.map((question) => (
            <Card key={question.id} className="p-6 border-0 shadow-md hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{question.title}</h3>
                    <Badge variant="outline">{question.question_type.replace("_", " ")}</Badge>
                  </div>
                  {question.description && <p className="text-gray-600 text-sm mb-3">{question.description}</p>}
                  <p className="text-gray-500 text-sm">Created {new Date(question.created_at).toLocaleDateString()}</p>
                </div>
                <div className="flex gap-2">
                  <Link href={`/teacher/questions/${question.id}/responses`}>
                    <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                      <Eye className="w-4 h-4" />
                      Responses
                    </Button>
                  </Link>
                  <Link href={`/teacher/questions/${question.id}/edit`}>
                    <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                      <Edit className="w-4 h-4" />
                      Edit
                    </Button>
                  </Link>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2 bg-transparent text-red-600 hover:text-red-700"
                    onClick={() => handleDelete(question.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
