"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ArrowLeft, Plus, X } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { QuestionType } from "@/lib/types"

export default function CreateQuestionPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [questionType, setQuestionType] = useState<QuestionType>("multiple_choice")
  const [options, setOptions] = useState(["", ""])
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    questionText: "",
    correctAnswer: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...options]
    newOptions[index] = value
    setOptions(newOptions)
  }

  const addOption = () => {
    setOptions([...options, ""])
  }

  const removeOption = (index: number) => {
    setOptions(options.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const supabase = getSupabaseClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/signin")
        return
      }

      const questionData: any = {
        teacher_id: user.id,
        title: formData.title,
        description: formData.description,
        question_text: formData.questionText,
        question_type: questionType,
      }

      if (questionType === "multiple_choice") {
        questionData.options = options.filter((o) => o.trim())
      } else if (questionType === "short_answer") {
        questionData.correct_answer = formData.correctAnswer
      }

      const { error } = await supabase.from("questions").insert(questionData)

      if (error) throw error

      router.push("/teacher/questions")
    } catch (error) {
      console.error("Error creating question:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <Link href="/teacher/questions">
        <Button variant="outline" className="mb-6 gap-2 bg-transparent">
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>
      </Link>

      <Card className="p-8 border-0 shadow-md">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Create New Question</h1>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Information */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900">Basic Information</h2>

            <div>
              <Label htmlFor="title">Question Title</Label>
              <Input
                id="title"
                name="title"
                placeholder="e.g., What is the capital of France?"
                value={formData.title}
                onChange={handleInputChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                name="description"
                placeholder="Add any additional context or instructions..."
                value={formData.description}
                onChange={handleInputChange}
                className="min-h-20"
              />
            </div>

            <div>
              <Label htmlFor="questionText">Question Text</Label>
              <Textarea
                id="questionText"
                name="questionText"
                placeholder="Enter the full question..."
                value={formData.questionText}
                onChange={handleInputChange}
                className="min-h-24"
                required
              />
            </div>
          </div>

          {/* Question Type */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900">Question Type</h2>

            <RadioGroup value={questionType} onValueChange={(value) => setQuestionType(value as QuestionType)}>
              <div className="flex items-center space-x-2 p-3 border border-gray-200 rounded-lg">
                <RadioGroupItem value="multiple_choice" id="multiple_choice" />
                <Label htmlFor="multiple_choice" className="cursor-pointer flex-1 font-normal">
                  Multiple Choice
                </Label>
              </div>

              <div className="flex items-center space-x-2 p-3 border border-gray-200 rounded-lg">
                <RadioGroupItem value="short_answer" id="short_answer" />
                <Label htmlFor="short_answer" className="cursor-pointer flex-1 font-normal">
                  Short Answer
                </Label>
              </div>

              <div className="flex items-center space-x-2 p-3 border border-gray-200 rounded-lg">
                <RadioGroupItem value="essay" id="essay" />
                <Label htmlFor="essay" className="cursor-pointer flex-1 font-normal">
                  Essay
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Question Type Specific Fields */}
          {questionType === "multiple_choice" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">Answer Options</h2>

              {options.map((option, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    placeholder={`Option ${index + 1}`}
                    value={option}
                    onChange={(e) => handleOptionChange(index, e.target.value)}
                    required
                  />
                  {options.length > 2 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeOption(index)}
                      className="bg-transparent"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}

              <Button type="button" variant="outline" onClick={addOption} className="gap-2 bg-transparent">
                <Plus className="w-4 h-4" />
                Add Option
              </Button>
            </div>
          )}

          {questionType === "short_answer" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">Correct Answer</h2>

              <div>
                <Label htmlFor="correctAnswer">Enter the correct answer</Label>
                <Input
                  id="correctAnswer"
                  name="correctAnswer"
                  placeholder="The correct answer..."
                  value={formData.correctAnswer}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>
          )}

          {/* Submit Buttons */}
          <div className="flex gap-4 pt-4">
            <Button type="submit" disabled={loading}>
              {loading ? "Creating..." : "Create Question"}
            </Button>
            <Link href="/teacher/questions">
              <Button type="button" variant="outline" className="bg-transparent">
                Cancel
              </Button>
            </Link>
          </div>
        </form>
      </Card>
    </div>
  )
}
