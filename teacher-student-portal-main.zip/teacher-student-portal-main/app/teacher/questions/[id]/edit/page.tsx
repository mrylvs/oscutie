"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Plus, X } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Question, QuestionType } from "@/lib/types"

export default function EditQuestionPage() {
  const router = useRouter()
  const params = useParams()
  const questionId = params.id as string

  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [question, setQuestion] = useState<Question | null>(null)
  const [questionType, setQuestionType] = useState<QuestionType>("multiple_choice")
  const [options, setOptions] = useState<string[]>([])
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    questionText: "",
    correctAnswer: "",
  })

  useEffect(() => {
    const fetchQuestion = async () => {
      const supabase = getSupabaseClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/signin")
        return
      }

      const { data } = await supabase
        .from("questions")
        .select("*")
        .eq("id", questionId)
        .eq("teacher_id", user.id)
        .single()

      if (!data) {
        router.push("/teacher/questions")
        return
      }

      setQuestion(data)
      setQuestionType(data.question_type)
      setFormData({
        title: data.title,
        description: data.description || "",
        questionText: data.question_text,
        correctAnswer: data.correct_answer || "",
      })

      if (data.question_type === "multiple_choice" && data.options) {
        setOptions(data.options)
      }

      setLoading(false)
    }

    fetchQuestion()
  }, [questionId, router])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...options]
    newOptions[index] = value
    setOptions(newOptions)
  }

  const addOption = () => {
    setOptions([...options, ""])
  }

  const removeOption = (index: number) => {
    setOptions(options.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!question) return

    setSubmitting(true)

    try {
      const supabase = getSupabaseClient()

      const updateData: any = {
        title: formData.title,
        description: formData.description,
        question_text: formData.questionText,
      }

      if (questionType === "multiple_choice") {
        updateData.options = options.filter((o) => o.trim())
      } else if (questionType === "short_answer") {
        updateData.correct_answer = formData.correctAnswer
      }

      const { error } = await supabase.from("questions").update(updateData).eq("id", questionId)

      if (error) throw error

      router.push("/teacher/questions")
    } catch (error) {
      console.error("Error updating question:", error)
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading question...</p>
        </div>
      </div>
    )
  }

  if (!question) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">Question not found</p>
      </div>
    )
  }

  return (
    <div>
      <Link href="/teacher/questions">
        <Button variant="outline" className="mb-6 gap-2 bg-transparent">
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>
      </Link>

      <Card className="p-8 border-0 shadow-md">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Edit Question</h1>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Information */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900">Basic Information</h2>

            <div>
              <Label htmlFor="title">Question Title</Label>
              <Input id="title" name="title" value={formData.title} onChange={handleInputChange} required />
            </div>

            <div>
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                className="min-h-20"
              />
            </div>

            <div>
              <Label htmlFor="questionText">Question Text</Label>
              <Textarea
                id="questionText"
                name="questionText"
                value={formData.questionText}
                onChange={handleInputChange}
                className="min-h-24"
                required
              />
            </div>
          </div>

          {/* Question Type (Read-only) */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900">Question Type</h2>
            <p className="text-gray-600 text-sm">
              Question type cannot be changed. Current type:{" "}
              <span className="font-semibold">{questionType.replace("_", " ")}</span>
            </p>
          </div>

          {/* Question Type Specific Fields */}
          {questionType === "multiple_choice" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">Answer Options</h2>

              {options.map((option, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    placeholder={`Option ${index + 1}`}
                    value={option}
                    onChange={(e) => handleOptionChange(index, e.target.value)}
                    required
                  />
                  {options.length > 2 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeOption(index)}
                      className="bg-transparent"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}

              <Button type="button" variant="outline" onClick={addOption} className="gap-2 bg-transparent">
                <Plus className="w-4 h-4" />
                Add Option
              </Button>
            </div>
          )}

          {questionType === "short_answer" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">Correct Answer</h2>

              <div>
                <Label htmlFor="correctAnswer">Enter the correct answer</Label>
                <Input
                  id="correctAnswer"
                  name="correctAnswer"
                  value={formData.correctAnswer}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>
          )}

          {/* Submit Buttons */}
          <div className="flex gap-4 pt-4">
            <Button type="submit" disabled={submitting}>
              {submitting ? "Saving..." : "Save Changes"}
            </Button>
            <Link href="/teacher/questions">
              <Button type="button" variant="outline" className="bg-transparent">
                Cancel
              </Button>
            </Link>
          </div>
        </form>
      </Card>
    </div>
  )
}
