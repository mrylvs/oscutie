"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, CheckCircle, XCircle } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Question, StudentResponse } from "@/lib/types"

interface ResponseWithStudent extends StudentResponse {
  student_name?: string
  student_email?: string
}

export default function QuestionResponsesPage() {
  const router = useRouter()
  const params = useParams()
  const questionId = params.id as string

  const [question, setQuestion] = useState<Question | null>(null)
  const [responses, setResponses] = useState<ResponseWithStudent[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const supabase = getSupabaseClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/signin")
        return
      }

      // Fetch question
      const { data: questionData } = await supabase
        .from("questions")
        .select("*")
        .eq("id", questionId)
        .eq("teacher_id", user.id)
        .single()

      if (!questionData) {
        router.push("/teacher/questions")
        return
      }

      setQuestion(questionData)

      // Fetch responses
      const { data: responsesData } = await supabase.from("student_responses").select("*").eq("question_id", questionId)

      // Fetch student names
      if (responsesData) {
        const studentIds = [...new Set(responsesData.map((r) => r.student_id))]
        const { data: studentsData } = await supabase.from("users").select("id, full_name, email").in("id", studentIds)

        const studentsMap = new Map(studentsData?.map((s) => [s.id, s]) || [])

        const responsesWithStudents = responsesData.map((r) => ({
          ...r,
          student_name: studentsMap.get(r.student_id)?.full_name,
          student_email: studentsMap.get(r.student_id)?.email,
        }))

        setResponses(responsesWithStudents)
      }

      setLoading(false)
    }

    fetchData()
  }, [questionId, router])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading responses...</p>
        </div>
      </div>
    )
  }

  if (!question) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">Question not found</p>
      </div>
    )
  }

  const correctCount = responses.filter((r) => r.is_correct).length
  const accuracy = responses.length > 0 ? Math.round((correctCount / responses.length) * 100) : 0

  return (
    <div>
      <Link href="/teacher/questions">
        <Button variant="outline" className="mb-6 gap-2 bg-transparent">
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>
      </Link>

      <Card className="p-8 border-0 shadow-md mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{question.title}</h1>
        <p className="text-gray-600 mb-6">{question.question_text}</p>

        <div className="grid md:grid-cols-3 gap-4">
          <div className="p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-gray-600">Total Responses</p>
            <p className="text-2xl font-bold text-gray-900">{responses.length}</p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg">
            <p className="text-sm text-gray-600">Correct Answers</p>
            <p className="text-2xl font-bold text-gray-900">{correctCount}</p>
          </div>
          <div className="p-4 bg-amber-50 rounded-lg">
            <p className="text-sm text-gray-600">Accuracy Rate</p>
            <p className="text-2xl font-bold text-gray-900">{accuracy}%</p>
          </div>
        </div>
      </Card>

      <h2 className="text-2xl font-bold text-gray-900 mb-6">Student Responses</h2>

      {responses.length === 0 ? (
        <Card className="p-12 text-center border-0 shadow-md">
          <p className="text-gray-600 text-lg">No responses yet</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {responses.map((response) => (
            <Card key={response.id} className="p-6 border-0 shadow-md">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <h3 className="font-semibold text-gray-900">{response.student_name}</h3>
                  <p className="text-sm text-gray-600">{response.student_email}</p>
                </div>
                {response.is_correct !== null && (
                  <Badge variant={response.is_correct ? "default" : "secondary"}>
                    {response.is_correct ? (
                      <span className="flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        Correct
                      </span>
                    ) : (
                      <span className="flex items-center gap-1">
                        <XCircle className="w-3 h-3" />
                        Incorrect
                      </span>
                    )}
                  </Badge>
                )}
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">Student's Answer:</p>
                <p className="text-gray-900 font-medium">{response.answer}</p>
              </div>

              {question.question_type === "short_answer" && question.correct_answer && (
                <div className="bg-blue-50 p-4 rounded-lg mt-4">
                  <p className="text-sm text-gray-600 mb-2">Expected Answer:</p>
                  <p className="text-gray-900 font-medium">{question.correct_answer}</p>
                </div>
              )}

              <p className="text-xs text-gray-500 mt-4">
                Submitted: {new Date(response.submitted_at).toLocaleString()}
              </p>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
