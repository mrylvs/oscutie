"use server"

import { createClient } from "@/lib/supabase/server"

export async function signUpUser(
  email: string,
  password: string,
  fullName: string,
  role: "teacher" | "student",
  schoolName?: string,
  subject?: string,
) {
  const supabase = await createClient()

  try {
    // Sign up with Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/auth/callback`,
      },
    })

    if (authError) {
      return { error: authError.message }
    }

    if (!authData.user) {
      return { error: "Failed to create user" }
    }

    // Create user profile in database
    const { error: profileError } = await supabase.from("users").insert({
      id: authData.user.id,
      email,
      full_name: fullName,
      role,
      school_name: schoolName || null,
      subject_grade: subject || null,
    })

    if (profileError) {
      // If profile creation fails, we should ideally delete the auth user
      // but for now we'll just return the error
      return { error: `Profile creation failed: ${profileError.message}` }
    }

    return { success: true, userId: authData.user.id }
  } catch (err) {
    return { error: err instanceof Error ? err.message : "An error occurred" }
  }
}

export async function getUserRole(userId: string) {
  const supabase = await createClient()

  try {
    const { data, error } = await supabase.from("users").select("role").eq("id", userId).single()

    if (error) {
      console.log("Error fetching user role:", error)
      return { error: error.message }
    }

    return { role: data?.role }
  } catch (err) {
    console.log("Exception fetching user role:", err)
    return { error: err instanceof Error ? err.message : "Failed to fetch user role" }
  }
}
