"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { CheckCircle, Clock, AlertCircle } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"

interface StudentStats {
  totalQuestions: number
  answeredQuestions: number
  correctAnswers: number
  pendingQuestions: number
}

export default function StudentDashboard() {
  const [stats, setStats] = useState<StudentStats>({
    totalQuestions: 0,
    answeredQuestions: 0,
    correctAnswers: 0,
    pendingQuestions: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      const supabase = getSupabaseClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) return

      // Get total questions
      const { data: allQuestions } = await supabase.from("questions").select("id")

      // Get student responses
      const { data: responses } = await supabase.from("student_responses").select("*").eq("student_id", user.id)

      const totalQuestions = allQuestions?.length || 0
      const answeredQuestions = responses?.length || 0
      const correctAnswers = responses?.filter((r) => r.is_correct).length || 0
      const pendingQuestions = totalQuestions - answeredQuestions

      setStats({
        totalQuestions,
        answeredQuestions,
        correctAnswers,
        pendingQuestions,
      })
      setLoading(false)
    }

    fetchStats()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Welcome to Your Dashboard</h1>

      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <Card className="p-6 border-0 shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Total Questions</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalQuestions}</p>
            </div>
            <AlertCircle className="w-12 h-12 text-blue-100" />
          </div>
        </Card>

        <Card className="p-6 border-0 shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Answered</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.answeredQuestions}</p>
            </div>
            <CheckCircle className="w-12 h-12 text-green-100" />
          </div>
        </Card>

        <Card className="p-6 border-0 shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Correct</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.correctAnswers}</p>
            </div>
            <CheckCircle className="w-12 h-12 text-emerald-100" />
          </div>
        </Card>

        <Card className="p-6 border-0 shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Pending</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.pendingQuestions}</p>
            </div>
            <Clock className="w-12 h-12 text-amber-100" />
          </div>
        </Card>
      </div>

      <Card className="p-8 border-0 shadow-md">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Your Progress</h2>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Completion Rate</span>
              <span className="text-sm font-bold text-gray-900">
                {stats.totalQuestions > 0 ? Math.round((stats.answeredQuestions / stats.totalQuestions) * 100) : 0}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all"
                style={{
                  width: `${stats.totalQuestions > 0 ? (stats.answeredQuestions / stats.totalQuestions) * 100 : 0}%`,
                }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Accuracy Rate</span>
              <span className="text-sm font-bold text-gray-900">
                {stats.answeredQuestions > 0 ? Math.round((stats.correctAnswers / stats.answeredQuestions) * 100) : 0}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-green-600 h-2 rounded-full transition-all"
                style={{
                  width: `${stats.answeredQuestions > 0 ? (stats.correctAnswers / stats.answeredQuestions) * 100 : 0}%`,
                }}
              ></div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}
