"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { CheckCircle, ArrowLeft } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Question, StudentResponse } from "@/lib/types"

export default function QuestionDetailPage() {
  const router = useRouter()
  const params = useParams()
  const questionId = params.id as string

  const [question, setQuestion] = useState<Question | null>(null)
  const [response, setResponse] = useState<StudentResponse | null>(null)
  const [answer, setAnswer] = useState("")
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [userId, setUserId] = useState<string | null>(null)
  const [submitted, setSubmitted] = useState(false)

  useEffect(() => {
    const fetchQuestion = async () => {
      const supabase = getSupabaseClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/signin")
        return
      }

      setUserId(user.id)

      // Fetch question
      const { data: questionData } = await supabase.from("questions").select("*").eq("id", questionId).single()

      if (!questionData) {
        router.push("/student/questions")
        return
      }

      setQuestion(questionData)

      // Fetch existing response
      const { data: responseData } = await supabase
        .from("student_responses")
        .select("*")
        .eq("question_id", questionId)
        .eq("student_id", user.id)
        .single()

      if (responseData) {
        setResponse(responseData)
        setAnswer(responseData.answer)
        setSubmitted(true)
      }

      setLoading(false)
    }

    fetchQuestion()
  }, [questionId, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!question || !userId || !answer.trim()) return

    setSubmitting(true)

    try {
      const supabase = getSupabaseClient()

      let isCorrect = null

      // Check if answer is correct for short answer questions
      if (question.question_type === "short_answer" && question.correct_answer) {
        isCorrect = answer.toLowerCase().trim() === question.correct_answer.toLowerCase().trim()
      }

      if (response) {
        // Update existing response
        const { error } = await supabase
          .from("student_responses")
          .update({
            answer,
            is_correct: isCorrect,
            submitted_at: new Date().toISOString(),
          })
          .eq("id", response.id)

        if (error) throw error
      } else {
        // Insert new response
        const { error } = await supabase.from("student_responses").insert({
          question_id: question.id,
          student_id: userId,
          answer,
          is_correct: isCorrect,
        })

        if (error) throw error
      }

      setSubmitted(true)
      setResponse({
        id: response?.id || "",
        question_id: question.id,
        student_id: userId,
        answer,
        is_correct: isCorrect,
        submitted_at: new Date().toISOString(),
      })
    } catch (error) {
      console.error("Error submitting answer:", error)
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading question...</p>
        </div>
      </div>
    )
  }

  if (!question) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">Question not found</p>
      </div>
    )
  }

  return (
    <div>
      <Button variant="outline" className="mb-6 gap-2 bg-transparent" onClick={() => router.back()}>
        <ArrowLeft className="w-4 h-4" />
        Back
      </Button>

      <Card className="p-8 border-0 shadow-md mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">{question.title}</h1>
        {question.description && <p className="text-gray-600 mb-6">{question.description}</p>}

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
          <p className="text-gray-900 text-lg font-medium">{question.question_text}</p>
        </div>

        {submitted && response && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-green-900">Answer Submitted</p>
              {response.is_correct !== null && (
                <p className="text-sm text-green-700 mt-1">
                  {response.is_correct ? "Your answer is correct!" : "Your answer was submitted for review."}
                </p>
              )}
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {question.question_type === "multiple_choice" && question.options && (
            <div className="space-y-3">
              <Label className="text-base font-semibold">Select your answer:</Label>
              <RadioGroup value={answer} onValueChange={setAnswer}>
                {question.options.map((option, index) => (
                  <div
                    key={index}
                    className="flex items-center space-x-2 p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    <RadioGroupItem value={option} id={`option-${index}`} />
                    <Label htmlFor={`option-${index}`} className="cursor-pointer flex-1 font-normal">
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          )}

          {(question.question_type === "short_answer" || question.question_type === "essay") && (
            <div>
              <Label htmlFor="answer" className="text-base font-semibold">
                Your Answer:
              </Label>
              <Textarea
                id="answer"
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="Enter your answer here..."
                className="mt-2 min-h-32"
                disabled={submitted}
              />
            </div>
          )}

          {!submitted && (
            <Button type="submit" className="w-full" disabled={submitting || !answer.trim()}>
              {submitting ? "Submitting..." : "Submit Answer"}
            </Button>
          )}
        </form>
      </Card>
    </div>
  )
}
