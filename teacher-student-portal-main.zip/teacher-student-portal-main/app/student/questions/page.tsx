"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, ArrowRight } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Question } from "@/lib/types"

interface QuestionWithStatus extends Question {
  answered: boolean
  isCorrect: boolean | null
}

export default function StudentQuestionsPage() {
  const [questions, setQuestions] = useState<QuestionWithStatus[]>([])
  const [loading, setLoading] = useState(true)
  const [userId, setUserId] = useState<string | null>(null)

  useEffect(() => {
    const fetchQuestions = async () => {
      const supabase = getSupabaseClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) return

      setUserId(user.id)

      // Get all questions
      const { data: allQuestions } = await supabase.from("questions").select("*")

      // Get student responses
      const { data: responses } = await supabase.from("student_responses").select("*").eq("student_id", user.id)

      const responsesMap = new Map(responses?.map((r) => [r.question_id, r]) || [])

      const questionsWithStatus = (allQuestions || []).map((q) => ({
        ...q,
        answered: responsesMap.has(q.id),
        isCorrect: responsesMap.get(q.id)?.is_correct || null,
      }))

      setQuestions(questionsWithStatus)
      setLoading(false)
    }

    fetchQuestions()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading questions...</p>
        </div>
      </div>
    )
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Available Questions</h1>

      {questions.length === 0 ? (
        <Card className="p-12 text-center border-0 shadow-md">
          <p className="text-gray-600 text-lg">No questions available yet. Check back soon!</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {questions.map((question) => (
            <Card key={question.id} className="p-6 border-0 shadow-md hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{question.title}</h3>
                    {question.answered && (
                      <Badge variant={question.isCorrect ? "default" : "secondary"}>
                        {question.isCorrect ? "Correct" : "Answered"}
                      </Badge>
                    )}
                    {!question.answered && <Badge variant="outline">Pending</Badge>}
                  </div>
                  {question.description && <p className="text-gray-600 text-sm mb-3">{question.description}</p>}
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {question.question_type.replace("_", " ")}
                    </span>
                  </div>
                </div>
                <Link href={`/student/questions/${question.id}`}>
                  <Button className="gap-2">
                    {question.answered ? "Review" : "Answer"}
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
